const express = require('express');
const router = express.Router();
const Review = require('../models/Review');

// Yeni inceleme ekleme
router.post('/add', async (req, res) => {
  try {
    const { propertyAddress, rating, title, comment, name, email } = req.body;
    const newReview = await Review.create({ propertyAddress, rating, title, comment, name, email });
    res.status(201).json(newReview);
  } catch (error) {
    res.status(500).json({ message: 'Error adding review', error });
  }
});

// Tüm incelemeleri listeleme
router.get('/', async (req, res) => {
  try {
    const reviews = await Review.findAll();
    res.json(reviews);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching reviews', error });
  }
});

module.exports = router;
