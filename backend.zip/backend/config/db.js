const sql = require('mssql');

// MSSQL bağlantı ayarları (SABİT DEĞERLER)
const config = {
  server: 'DESKTOP-4MRKT8H',
  database: 'setyouroffer',
  options: {
    trustedConnection: true, // Windows Authentication aktif!
    encrypt: false,
    trustServerCertificate: true,
  },
};


// Veritabanına bağlanma fonksiyonu
const connectDB = async () => {
  try {
    await sql.connect(config);
    console.log('✅ MSSQL veritabanına başarıyla bağlandı.');
  } catch (error) {
    console.error('❌ MSSQL bağlantı hatası:', error);
    process.exit(1); // Hata olursa uygulamayı durdur
  }
};

module.exports = { connectDB, sql };
