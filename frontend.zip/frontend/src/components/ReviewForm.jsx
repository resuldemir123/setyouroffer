// src/components/ReviewForm.jsx
import React, { useState } from 'react';

function ReviewForm() {
  const [reviewData, setReviewData] = useState({
    propertyAddress: '',
    rating: 5,
    title: '',
    comment: '',
    name: '',
    email: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setReviewData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      const response = await fetch('http://localhost:5000/api/reviews/add', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(reviewData),
      });
  
      if (response.ok) {
        console.log('Review successfully submitted');
        setReviewData({ propertyAddress: '', rating: 5, title: '', comment: '', name: '', email: '' });
      } else {
        console.error('Error submitting review');
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };
  

  return (
    <form className="review-form" onSubmit={handleSubmit}>
      <h3>Leave a Review</h3>
      
      <div className="form-group">
        <label htmlFor="propertyAddress">Property Address</label>
        <input
          type="text"
          id="propertyAddress"
          name="propertyAddress"
          value={reviewData.propertyAddress}
          onChange={handleChange}
          required
        />
      </div>
      
      <div className="form-group">
        <label htmlFor="rating">Rating</label>
        <select
          id="rating"
          name="rating"
          value={reviewData.rating}
          onChange={handleChange}
        >
          <option value="5">5 Stars</option>
          <option value="4">4 Stars</option>
          <option value="3">3 Stars</option>
          <option value="2">2 Stars</option>
          <option value="1">1 Star</option>
        </select>
      </div>
      
      <div className="form-group">
        <label htmlFor="title">Review Title</label>
        <input
          type="text"
          id="title"
          name="title"
          value={reviewData.title}
          onChange={handleChange}
          required
        />
      </div>
      
      <div className="form-group">
        <label htmlFor="comment">Your Review</label>
        <textarea
          id="comment"
          name="comment"
          rows="4"
          value={reviewData.comment}
          onChange={handleChange}
          required
        ></textarea>
      </div>
      
      <div className="form-group">
        <label htmlFor="name">Your Name</label>
        <input
          type="text"
          id="name"
          name="name"
          value={reviewData.name}
          onChange={handleChange}
          required
        />
      </div>
      
      <div className="form-group">
        <label htmlFor="email">Email</label>
        <input
          type="email"
          id="email"
          name="email"
          value={reviewData.email}
          onChange={handleChange}
          required
        />
      </div>
      
      <button type="submit" className="submit-button">Submit Review</button>
    </form>
  );
}

export default ReviewForm;