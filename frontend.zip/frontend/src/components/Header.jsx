// src/components/Header.jsx
import React from 'react';


function Header() {
  return (
    <header className="main-header">
      <nav className="nav-left">
        <a href="#" className="nav-item">Buy</a>
        <a href="#" className="nav-item">Rent</a>
        <a href="#" className="nav-item">Sell</a>
        <a href="#" className="nav-item">Home Loans</a>
        <a href="#" className="nav-item">Find an Agent</a>
      </nav>
      
      <div className="logo">
  <a href="#">
    <img src="/images/D.png" alt="Demir Emlak" />
    <span className="logo-text">Demir Emlak</span>
  </a>
</div>

      
      <nav className="nav-right">
        <a href="#" className="nav-item">Manage Rentals</a>
        <a href="#" className="nav-item">Advertise</a>
        <a href="#" className="nav-item">Help</a>
        <a href="#" className="nav-item">Sign In</a>
      </nav>
    </header>
  );
}

export default Header;