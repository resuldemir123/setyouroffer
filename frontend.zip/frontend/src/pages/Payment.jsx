import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import Footer from '../components/footer';
import Header from '../components/Header';
import PaymentForm from '../components/PaymentForm';

const Payment = () => {
  const { id } = useParams();
  const [paymentStatus, setPaymentStatus] = useState('');

  const handlePaymentSubmit = async (data) => {
    // Add payment logic here
    setPaymentStatus('Payment successful!');
  };

  return (
    <div>
      <Header />
      <h2>Make Payment</h2>
      <PaymentForm listingId={id} onSubmit={handlePaymentSubmit} />
      {paymentStatus && <p>{paymentStatus}</p>}
      <Footer />
    </div>
  );
};

export default Payment;