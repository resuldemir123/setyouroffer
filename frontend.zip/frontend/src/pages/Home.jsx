import React from 'react';
import Footer from '../components/footer';
import Header from '../components/Header';

const Home = () => {
  return (
    <div>
      <Header />
      <h2>Welcome to Set Your Offer</h2>
      <p>Find your dream property here!</p>
      <Footer />
    </div>
  );
};

export default Home;