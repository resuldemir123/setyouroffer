import axios from 'axios';
import React, { useEffect, useState } from 'react';
import Footer from '../components/footer';
import Header from '../components/Header';
import ListingCard from '../components/ListingCard';

const Listings = () => {
  const [listings, setListings] = useState([]);

  useEffect(() => {
    axios.get('/api/listings')
      .then(response => setListings(response.data))
      .catch(error => console.error(error));
  }, []);

  return (
    <div>
      <Header />
      <h2>Listings</h2>
      {listings.map(listing => (
        <ListingCard key={listing._id} listing={listing} />
      ))}
      <Footer />
    </div>
  );
};

export default Listings;