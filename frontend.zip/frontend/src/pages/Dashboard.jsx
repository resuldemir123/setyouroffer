import React from 'react';
import Footer from '../components/footer';
import Header from '../components/Header';

const Dashboard = () => {
  return (
    <div>
      <Header />
      <h2>Dashboard</h2>
      <p>Welcome to your dashboard!</p>
      <Footer />
    </div>
  );
};

export default Dashboard;