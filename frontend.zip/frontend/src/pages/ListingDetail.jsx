import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import Footer from '../components/footer';
import Header from '../components/Header';
import OfferForm from '../components/OfferForm';
import ReviewForm from '../components/ReviewForm';

const ListingDetail = () => {
  const { id } = useParams();
  const [listing, setListing] = useState(null);

  useEffect(() => {
    axios.get(`/api/listings/${id}`)
      .then(response => setListing(response.data))
      .catch(error => console.error(error));
  }, [id]);

  if (!listing) return <div>Loading...</div>;

  return (
    <div>
      <Header />
      <h2>{listing.title}</h2>
      <p>{listing.description}</p>
      <p>Price: ${listing.price}</p>
      <OfferForm listingId={listing._id} onSubmit={(data) => console.log(data)} />
      <ReviewForm listingId={listing._id} onSubmit={(data) => console.log(data)} />
      <Footer />
    </div>
  );
};

export default ListingDetail;